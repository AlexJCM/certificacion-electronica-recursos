/**
 * Se crea un módulo y se lo carga en la aplicación agregándolo como módulo dependiente.
 * 
 */ 
angular.module('bonitasoft.ui.extensions', ['ngSanitize'])
    .filter('labelized', [
        function () {
            return function toType(input) {
                return (
                    '<span class="label label-' + severity(input) + '">' +
                        input.toUpperCase() +
                    '</span>'
                )
            }
        }
    ])
    .filter('boolenized', [
        function () {
            return function convertBool(input) {
                return changeBool(input)
            }
        }
    ])

/**
 * Permite retornar la clase css correspondiente para modifcar el estilo.
 * 
 * @param {string}
 * @return {string}
 */
function severity(status) {
    switch (status) {
        case 'Pendiente': return 'warning'
        case 'Enviado': return 'success'
        case 'Rechazada': return 'danger'
        case 'Aprobada': return 'primary'
        default: return 'default'
    }
}

/**
 * Permite cambiar true por 'Si' y false por 'No'.
 * 
 * @param {boolean}
 * @return {string}
 */ 
function changeBool(boolToConvert) {
    if (boolToConvert === true) {
        return 'Si'
    } else if (boolToConvert === false) {
        return 'No'
    }
    return 'default'    
}
