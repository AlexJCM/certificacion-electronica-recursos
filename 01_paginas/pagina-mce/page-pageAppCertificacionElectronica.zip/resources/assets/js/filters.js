angular.module('bonitasoft.ui.extensions',['ngSanitize'])
 .filter('labelized', [function () {
   return function toType(input) {
     return "<span class=\"label label-"+severity(input)+"\">"+ input.toUpperCase() +"</span>";
   };
}]).filter('boolenized', [function () {
   return function convertBool(input) {
 	return changeBool(input)
   };
}]);

function severity(status){
    switch(status) {     
     case "Pendiente": return "warning";
     case "Enviado": return "success";
     case "Rechazada": return "danger";
     case "Aprobada": return "primary"; 
     default:
       return "default";
   }
}

function changeBool(boolToConvert){
    if (boolToConvert === true) {
        return "Si"
    } else if (boolToConvert === false) {
        return "No"
    } else {
        return "default"
    }
}
