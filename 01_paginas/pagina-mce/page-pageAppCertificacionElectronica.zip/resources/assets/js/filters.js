/**
 * Se crea un módulo y se lo carga en la aplicación agregándolo como módulo dependiente.
 * 
 */ 
angular.module('bonitasoft.ui.extensions', ['ngSanitize'])
    .filter('labelized', [
        function () {
            return function toType(input) {
                return (
                    '<span class="label label-' + severity(input) + '">' +
                        input.toUpperCase() +
                    '</span>'
                )
            }
        }
    ])
    .filter('boolenized', [
        function () {
            return function convertBool(input) {
                return changeBool(input)
            }
        }
    ])
    .filter('codenized', [
        function () {
            return function formatCode(code) {
                return codeToString(code)
            }
        }
    ])

/**
 * Permite retornar la clase css correspondiente para modifcar el estilo.
 * 
 * @param {string}
 * @return {string}
 */
function severity(status) {
    switch (status) {
        case 'Pendiente': return 'warning'
        case 'Enviado': return 'success'
        case 'Rechazada': return 'danger'
        case 'Aprobada': return 'primary'
        default: return 'default'
    }
}

/**
 * Permite cambiar true por 'Si' y false por 'No'.
 * 
 * @param {boolean}
 * @return {string}
 */ 
function changeBool(boolToConvert) {
    if (boolToConvert === true) {
        return 'Si'
    } else if (boolToConvert === false) {
        return 'No'
    }
    return 'default'    
}


/**
 * Permite agregar ceros a la izquierda de un número con menos de 
 * 4 dígitos.
 * 
 * @param {Long}
 * @return {string}
 */ 
function codeToString(code) {
  if (code) {
    let codeString = code.toString();
    let sizeCode = codeString.length;
    let sizeDefault = 4;
    if (sizeCode < sizeDefault) {
      return String(code).padStart(sizeDefault, "0")
    }
    return codeString;
  }
}