(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customHelpButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: function PbHelpLinkCtrl($scope) {

  'use strict';

  this.getHref = function () {
      return $scope.properties.targetLink;
  };
  
}
,
      template: '<div class="text-right boton-ayuda">\n  <a\n    class="btn btn-link"\n    ng-href="{{ctrl.getHref()}}"\n    data-toggle="tooltip"\n    title="Click aquí para acceder al manual de usuario"\n    target="_blank"\n  > \n  <div class="buttonHelp">\n      <div class="textButtonHelp">Ayuda</div>\n      <div><i class="glyphicon glyphicon-question-sign"></i></div>\n  </div>\n  </a>\n</div>\n'
    };
  });
