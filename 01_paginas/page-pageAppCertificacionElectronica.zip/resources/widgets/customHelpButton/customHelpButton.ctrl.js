function PbHelpLinkCtrl($scope) {

  'use strict';

  this.getHref = function () {
      return $scope.properties.targetLink;
  };
  
}
