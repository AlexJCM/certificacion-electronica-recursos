/**
 * Se crea un módulo y se lo carga en la aplicación agregándolo como módulo dependiente.
 * 
 */ 
angular.module('bonitasoft.ui.extensions', ['ngSanitize'])
    .filter('labelized', [
        function () {
            return function toType(input) {
                return (
                    '<span class="label label-' + severity(input) + '">' + input + '</span>'
                )
            }
        }
    ])
    .filter('boolenized', [
        function () {
            return function convertBool(input) {
                return changeBool(input)
            }
        }
    ])
    .filter('codenized', [
        function () {
            return function formatCode(code) {
                return codeToString(code)
            }
        }
    ])

/**
 * Permite retornar la clase css correspondiente para modifcar el estilo.
 * 
 * @param {string}
 * @return {string}
 */
function severity(status) {
    switch (status) {
        case 'PENDIENTE': return 'warning'
        case 'ENVIADO': return 'success'
        case 'RECHAZADA': return 'danger'
        case 'APROBADA': return 'primary'
        default: return 'default'
    }
}

/**
 * Permite cambiar true por 'Si' y false por 'No'.
 * 
 * @param {boolean}
 * @return {string}
 */ 
function changeBool(boolToConvert) {
    if (boolToConvert === true) {
        return 'Si'
    } else if (boolToConvert === false) {
        return 'No'
    }
    return 'default'    
}


/**
 * Permite agregar ceros a la izquierda hasta completar 5 dígitos en un número con menos de 
 * 5 dígitos.
 * 
 * @param {Long}
 * @return {string}
 */ 
function codeToString(code) {
  if (code) {
    let codeString = code.toString();
    let sizeCode = codeString.length;
    let sizeDefault = 5;
    if (sizeCode < sizeDefault) {
      return String(code).padStart(sizeDefault, "0")
    }
    return codeString;
  }
}